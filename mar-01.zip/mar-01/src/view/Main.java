package view;

import java.util.List;
import java.util.Scanner;

import model.Employee;
import model.EmployeeDao;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		EmployeeDao edao=new EmployeeDao();
		int choice=0;
		do
		{
			System.out.println("	1) Add Employee\r\n" + 
					"	2) Modify Employee\r\n" + 
					"	3) Delete Employee\r\n"	+
					"	4) Display All Employees\r\n" + 
					"	5) Find Employee by Id\r\n" + 
					"	6) Exit");
			choice=sc.nextInt();
			Integer employeeId;
			String firstName;
			String lastName;
			String department;
			Employee employee=null;
			switch(choice)
			{
			case 1:		//add
				employee = getEmployeeDetils(sc);
				edao.create(employee);
				System.out.println("Employee added successfully");
				break;
			case 2:		//modify
				employeeId=getEmployeeIdInput(sc);
				//display employee details based on id
				employee=edao.read(employeeId);
				if(employee==null)
					System.out.println("Sorry, no employee found for "+employeeId);
				else
				{
					System.out.println("Found...! \n"+employee);
					System.out.println("Enter first name:");
					firstName=sc.nextLine();
					if(firstName.equals(""))
						firstName=sc.nextLine();
					System.out.println("Enter last name:");
					lastName=sc.nextLine();
					System.out.println("Enter department:");
					department=sc.nextLine();
					employee=new Employee(employeeId, firstName, lastName, department);
					if(edao.update(employee)==null)
						System.out.println("Update failed. Please try again");
					System.out.println("Update is successful");
				}
				
				break;
			case 3:
				employeeId=getEmployeeIdInput(sc);
				employee=edao.read(employeeId);
				if(employee==null)
					System.out.println("Sorry, no employee found for "+employeeId);
				else
				{
					if(edao.delete(employeeId))
						System.out.printf("Employee %d deleted successfully\n4"
								+ "",employeeId);
					else
						System.out.println("Delete failed. Try again");
				}
				break;
			case 4:		//display
				List<Employee> employeeList = edao.read();
				for(Employee e : employeeList)
					System.out.println(e);
				break;
			case 5:		//find by id
				employeeId=getEmployeeIdInput(sc);
				employee=edao.read(employeeId);
				if(employee==null)
					System.out.println("Sorry, no employee found for "+employeeId);
				else
					System.out.println(employee);
				break;
			}
		}while(choice<6);
	}

	private static Employee getEmployeeDetils(Scanner sc) {
		Integer employeeId;
		String firstName;
		String lastName;
		String department;
		//get necessary inputs from user
		employeeId = getEmployeeIdInput(sc);
		System.out.println("Enter first name:");
		firstName=sc.nextLine();
		if(firstName.equals(""))
			firstName=sc.nextLine();
		System.out.println("Enter last name:");
		lastName=sc.nextLine();
		System.out.println("Enter department:");
		department=sc.nextLine();
		Employee employee=new Employee(employeeId, firstName, lastName, department);
		return employee;
	}

	private static Integer getEmployeeIdInput(Scanner sc) {
		Integer employeeId;
		System.out.println("Enter employee id:");
		employeeId=sc.nextInt();
		return employeeId;
	}
	
	
}
