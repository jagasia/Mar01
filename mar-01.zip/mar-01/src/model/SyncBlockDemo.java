package model;

class Passenger
{
	String name;
	public Passenger(String name)
	{
		this.name=name;
	}
	public void speak() throws InterruptedException
	{
		System.out.println("ENtering async block");
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread().getName()+""+i);
			Thread.sleep(1000);
		}
		System.out.println("entering sync block");
		synchronized (this) {
			for(int j=0;j<10;j++)
			{
				System.out.println(Thread.currentThread().getName()+"\t"+j);
				Thread.sleep(1000);
			}	
		}
		
		
	}
}
class T1 extends Thread
{
	Passenger passenger;
	public T1(Passenger passenger)
	{
		this.passenger=passenger;
	}
	public void run()
	{
		try {
			passenger.speak();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class SyncBlockDemo {

	public static void main(String[] args) {
		Passenger rama=new Passenger("Rama");
		Passenger siva=new Passenger("Siva");
		T1 t1=new T1(siva);
		T1 t2=new T1(siva);
		t1.setName("Thread 1");
		t2.setName("THread two...");
		t1.start();
		t2.start();
	}

}
