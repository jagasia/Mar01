package model;

class Odd extends Thread
{
	public void run()
	{
		for(int i=1;i<=20;i+=2)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}

class Even implements Runnable
{
	public void run()
	{
		for(int i=2;i<=20;i+=2)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public class Task1 {

	public static void main(String[] args) {
		//Odd extend Thread
		Odd t1=new Odd();
		t1.start();
		
		//Even implements Runnable
		Thread t2=new Thread(new Even());
		t2.start();
		
	}

}
