package model;

class MyThread extends Thread
{

	@Override
	public void run() {
		for(int i=0;i<20;i++)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
			}
		}
	}
	
}

public class Main_Thread1 {

	public static void main(String[] args) {
		MyThread t1=new MyThread();
		t1.start();
		for(int i=1000;i>0;i--)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
			}
		}
	}

}
