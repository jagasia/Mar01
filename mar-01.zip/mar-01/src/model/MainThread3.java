package model;

public class MainThread3 {

	public static void main(String[] args) {
		Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
				for(int i=500;i>0;i--)
				{
					System.out.println(i);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		});
		
		t2.start();
			
			Thread t1=new Thread(()-> {
				for(int i=1000;i>0;i--)
				{
					System.out.println(i);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						
					}
				}
			});
			t1.start();
			
			for(int i=0;i<20;i++)
			{
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					
				}
			}
	}

}
