package model;

import java.io.ObjectStreamClass;

public class Student {
//	private static final long serialVersionUID = 1L;
//	private static final long serialVersionUID = -6377573678240024862L;
//	private static final long serialVersionUID = -2984895889397033343L;
//	private static final long serialVersionUID = -2984895889397033343L;
	private static final 	long serialVersionUID;
	static {
	serialVersionUID = ObjectStreamClass.lookup(Student.class).getSerialVersionUID();
	}
	private int studentId;
	private String name;
	public Student() {}
	public Student(int studentId, String name) {
		super();
		this.studentId = studentId;
		this.name = name;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + "]";
	}
	
}
