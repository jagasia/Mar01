package model;

class Maths
{
	public synchronized void display() throws InterruptedException
	{
		System.out.println("Entering async block and displaying even numbers");
		for(int i=0;i<=20;i+=2)
		{
			System.out.println(Thread.currentThread().getName()+"\t..."+i);
			Thread.sleep(1000);
		}
		
//		synchronized (this) {
			System.out.println("Entering SYNC block and displaying odd numbers");
			for(int i=1;i<=20;i+=2)
			{
				System.out.println(Thread.currentThread().getName()+"\t..."+i);
				Thread.sleep(1000);
			}
//		}				
	}
}

class MathsThread extends Thread
{
	Maths m;
	public MathsThread(Maths m)
	{
		this.m=m;
	}
	public void run()
	{
		try {
			m.display();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class Task2 {

	public static void main(String[] args) {
		Maths m=new Maths();
		MathsThread t1=new MathsThread(m);
		MathsThread t2=new MathsThread(m);
		
		t1.setName("One...");
		t2.setName("Two...");
		
		t1.start();
		t2.start();
	}

}
