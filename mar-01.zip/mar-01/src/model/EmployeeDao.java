package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EmployeeDao {
	List<Employee> employeeList=new ArrayList<Employee>();
	
	public void create(Integer employeeId, String firstName, String lastName, String department)
	{
		Employee employee=new Employee();
		employee.setEmployeeId(employeeId);
		employee.setFirstName(firstName);
		employee.setLastName(lastName);
		employee.setDepartment(department);
		
		employeeList.add(employee);
		store();
	}
	public void create(Employee employee)
	{
		employeeList.add(employee);
		store();
	}
	public List<Employee> read()
	{
		load();
		return employeeList;
	}
	public Employee read(Integer employeeId)
	{
		load();
		//loop the employee list and check if current employee id is matching with argument id
		//find? then return that employee object
		for(Employee employee:employeeList)
		{
			if(employee.getEmployeeId().equals(employeeId))
				return employee;
		}
		return null;
	}
	
	public Employee update(Employee employee)
	{
		//find employee and update the details
		for(Employee e : employeeList)
		{
			if(e.getEmployeeId().equals(employee.getEmployeeId()))
			{
				e.setFirstName(employee.getFirstName());
				e.setLastName(employee.getLastName());
				e.setDepartment(employee.getDepartment());
				store();
				return e;
			}
		}
		return null;
	}
	public Boolean delete(Integer employeeId)
	{
		Iterator<Employee> it = employeeList.iterator();
		Boolean status=false;
		while(it.hasNext())
		{
			Employee employee = it.next();
			if(employee.getEmployeeId().equals(employeeId))
			{
				it.remove();
				store();
				status=true;
			}
		}
		return status;
	}
	
	public void store()
	{
		FileOutputStream fos=null;
		try {
			fos=new FileOutputStream("employee.dat");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(employeeList);
			oos.flush();
			oos.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void load()
	{
		FileInputStream fis=null;
		try {
			fis=new FileInputStream("employee.dat");
			ObjectInputStream ois=new ObjectInputStream(fis);
			List<Employee> employeeList=(List<Employee>) ois.readObject();
			this.employeeList=employeeList;
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
