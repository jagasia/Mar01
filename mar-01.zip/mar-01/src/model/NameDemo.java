package model;

class Thread2 extends Thread
{
	int no;
	public Thread2() {}
	
	public Thread2(int no) {
		this.no = no;
	}

	
	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public void run()
	{
		for(int i=no;i>0;i--)
		{
			System.out.println(getName()+"\t:\t"+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

public class NameDemo {

	public static void main(String[] args) throws InterruptedException {
		Thread2 t1, t2, t3;
		t1=new Thread2(555);
		t2=new Thread2(200);
		t3=new Thread2(111);
		
		t1.setName("One");
		t2.setName("Two");
		t3.setName("THree");
		
		t1.start();
		t2.start();
		t2.join(); 				//join() makes any new thread trying to start TO WAIT until all started threads complete
		t3.start();
	}

}
